
# -*- coding: utf-8 -*-
"""
Created on Thu Aug 22 14:23:30 2019

@author: pengdk
"""

#=======================================================================================================================
#=======================================================================================================================
import HistoryGreekOTCClose
import HistoryGreekOTCSettle
import HistoryGreekCtpjnClose
import HistoryGreekCtpjnSettle
import datetime
import os

import TotalClose
import TotalSettle

import BaseData as BD

def main_batch():
    curfile = os.path.realpath(__file__)
    curdir = os.path.dirname( os.path.dirname(curfile) )
    rootdir = os.path.join( curdir, "sharedata")

    #节假日
    oholiday = BD.CHolidayData()
    
    #指定一段时间，再获取这一段时间的工作日，然后逐日执行
    start = datetime.datetime(2019, 4, 30)
    end = datetime.datetime(2019, 6, 1)
    dt_list = oholiday.getWorklist(start, end)
    for dt_today in dt_list:
        #添加汇总用途
        _close_total_data = TotalClose.TotalCloseData()
        HistoryGreekOTCClose.g_total_data = _close_total_data
        HistoryGreekCtpjnClose.g_total_data = _close_total_data
    
        _settle_total_data = TotalClose.TotalCloseData()
        HistoryGreekOTCSettle.g_total_data = _settle_total_data
        HistoryGreekCtpjnSettle.g_total_data = _settle_total_data
    
        #正常计算和生成
        HistoryGreekOTCClose.main(rootdir, dt_today)
        HistoryGreekOTCSettle.main(rootdir, dt_today)
        HistoryGreekCtpjnClose.main(rootdir, dt_today)
        HistoryGreekCtpjnSettle.main(rootdir, dt_today)
    
        #汇总
        TotalClose.main(rootdir, _close_total_data, dt_today )
    
        TotalSettle.main(rootdir, _settle_total_data, dt_today)
        pass

    pass

def main():
    curfile = os.path.realpath(__file__)
    curdir = os.path.dirname( os.path.dirname(curfile) )
    rootdir = os.path.join( curdir, "sharedata")
    
    ###########################################
    #TODO
    #指定日期
    #dt_today = datetime.datetime.strptime("2019-05-14 15:00:00","%Y-%m-%d %H:%M:%S")
    dt_today = datetime.datetime.now()
    #TODO
    ############################################
    
    #添加汇总用途
    _close_total_data = TotalClose.TotalCloseData()
    HistoryGreekOTCClose.g_total_data = _close_total_data
    HistoryGreekCtpjnClose.g_total_data = _close_total_data
    
    _settle_total_data = TotalClose.TotalCloseData()
    HistoryGreekOTCSettle.g_total_data = _settle_total_data
    HistoryGreekCtpjnSettle.g_total_data = _settle_total_data
    
    #正常计算和生成
    HistoryGreekOTCClose.main(rootdir, dt_today)
    HistoryGreekOTCSettle.main(rootdir, dt_today)
    HistoryGreekCtpjnClose.main(rootdir, dt_today)
    HistoryGreekCtpjnSettle.main(rootdir, dt_today)
    
    #汇总
    TotalClose.main(rootdir, _close_total_data, dt_today )
    
    TotalSettle.main(rootdir, _settle_total_data, dt_today)
    
    pass


if __name__ == '__main__':
    #main_batch()
    main()
    
    pass


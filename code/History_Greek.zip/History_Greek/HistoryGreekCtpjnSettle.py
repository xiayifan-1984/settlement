# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 14:46:20 2019

@author: pengdk
"""

import re
import os
import datetime
import codecs 
import pandas as pd
import openpyxl
from openpyxl.styles import Color,Font,Alignment,PatternFill,Border,Side,Protection
import shutil

from collections import defaultdict

import WindDataHelper
import BaseData as BD

#模块级别的变量

#用来记录 交易员+品种+行号 ; 类型为TotalCloseData
g_total_data = None


#=======================================================================================================================
#功能:交易员信息
class Trader(object):
    def __init__(self, tradername):
        self._name = tradername
        self._hasOption = False         #该交易员是否交易期权,默认为False
        
        self._posmap = {}       #持仓信息map  key= 品种  value = newmap
                                #   newmap key=code, val = [持仓数量*买卖方向(买正卖负), 收盘价，合约乘数, 交易所]
        pass    

    #外部调用，设置外部数据来源
    def setBaseData(self,  snapData, productData ):
        self._snapData = snapData
        self._productData = productData
        pass
    
    def parseJNFile(self, filepath):
        fr = codecs.open(filepath, 'r','utf-8')
        lines = [l.rstrip('\n') for l in fr.readlines()]
        fr.close()

        if len(lines) == 0:
            return 
    
        flg = 0         #用于标识 当前需要进行何种操作
        pmap = []       #用于存储 持仓汇总里面的每一个字段
        
        for liner in lines:     
            line = liner.strip()
            if line.startswith('日期：'):
                self._realdate = line[line.find('：')+1:]
            elif line.startswith('账户：'):
                self._realaccount = line[line.find('：')+1:]
            elif line.strip() == '持仓汇总 Positions' :
                flg = 20
            elif line.strip() == '持仓汇总':   #金牛20190613之前的格式
                flg = 40
            elif len(line) == 0:
                if ( flg in range(20, 24) )  or (flg in range(40, 44) ):
                    pass
                else:
                    flg = 0
            elif re.match(r'^-*$',line):
                flg += 1
            else:
                if flg == 22:
                    args = [w.strip() for w in line.split('|')]
                    pmap.append(args)
                elif flg == 42:
                    args = [w.strip() for w in line.split('|')]
                    pmap.append(args)
                pass
        
        if len(pmap) > 0:
            pdf =pd.DataFrame(pmap)
            del pdf[0]    
            del pdf[9] 
            pdf[3] = pdf[3].astype('int')           #持仓量
                  
            pdf[9] = pdf[2].apply(lambda bs : 1 if bs == '买' else -1)
        else:
            pdf = None

        def lambda_ccpl(x):
            code = x[1]
            
            exch_id = self._productData.getExchange(code)
            mo_vm = self._productData.getMultiple(code)
            settleprice  =  self._snapData.getSettlePrice(code)
            
            product = self._productData.getProductByCode(code)
            if product in self._posmap:
                pass
            else:
                self._posmap[product] = { }
            
            if code in self._posmap[product]:
                self._posmap[product][code][0] += x[3]*x[9]
                pass
            else:
                self._posmap[product][code] = [ x[3]*x[9], settleprice, mo_vm, exch_id ]
            
            pass
        
        if pdf is not None:
            if len(pdf) > 0 :
                pdf.apply( lambda_ccpl, axis = 1)
                
        return None
    
    def parseCtpFile_Future(self, filepath):
        fr = codecs.open(filepath, 'r','utf-8')
        lines = [l.rstrip('\n') for l in fr.readlines()]
        fr.close()
        
        if len(lines) == 0:
            return 
    
        flg = 0         #用于标识 当前需要进行何种操作
        pmap = []       #用于存储 持仓汇总里面的每一个字段
        
        for liner in lines:     
            line = liner.strip()
            if line.strip() == '持仓汇总 Positions' :
                flg = 20
            elif len(line) == 0:
                if flg in range(20, 24) :       #在2019年6月份以前的ctp结算单,utf8格式， 存在0D 0D 0A 换行符的问题
                    pass
                else:
                    flg = 0     
            elif re.match(r'^-*$',line):
                flg += 1
            else:
                if flg == 22:
                    args = [w.strip() for w in line.split('|')]
                    pmap.append(args)
                pass
        
        
        
        if len(pmap) > 0:
            pdf =pd.DataFrame(pmap)
            del pdf[0]    
            del pdf[14] 
            pdf[3] = pdf[3].astype('int')           #买持仓量
            pdf[5] = pdf[5].astype('int')           #卖持仓量      
        else:
            pdf = None
            
        if pdf is None:
            return None
        
        if len(pdf) ==0 :
            return None
        
        def lambda_ccpl(x):
            code = x[2]
            
            exch_id = self._productData.getExchange(code)
            mo_vm = self._productData.getMultiple(code)
            settleprice  =  self._snapData.getSettlePrice(code)

            product = self._productData.getProductByCode(code)
            if product in self._posmap:
                pass
            else:
                self._posmap[product] = { }
            
            if code in self._posmap[product]:
                pass
            else:
                self._posmap[product][code] = [ x[3]-x[5], settleprice, mo_vm , exch_id]
            
            pass
        
        if pdf is not None:
            if len(pdf) > 0 :        
                pdf.apply( lambda_ccpl, axis = 1)
                
        return None

    #分析ctp结算单 [因为有些交易员交易期权，现阶段金牛不支持期权，所以期权只能从ctp中来]
    def parseCtpFile_Option(self, filepath, productlist):
        fr = codecs.open(filepath, 'r','utf-8')
        lines = [l.rstrip('\n') for l in fr.readlines()]
        fr.close()

        if len(lines) == 0:
            return 
    
        flg = 0         #用于标识 当前需要进行何种操作
        pmap = []       #用于存储 持仓汇总里面的每一个字段
        
        for liner in lines:     
            line = liner.strip()
            if line.strip() == '持仓汇总 Positions' :
                flg = 20
            elif len(line) == 0:
                if flg in range(20, 24):
                    pass
                else:
                    flg = 0
            elif re.match(r'^-*$',line):
                flg += 1
            else:
                if flg == 22:
                    args = [w.strip() for w in line.split('|')]
                    pmap.append(args)
                pass
        
        if len(pmap) > 0:
            pdf =pd.DataFrame(pmap)
            del pdf[0]    
            del pdf[14] 
            pdf[3] = pdf[3].astype('int')           #买持仓量
            pdf[5] = pdf[5].astype('int')           #卖持仓量      
        else:
            pdf = None
            
        if pdf is None:
            return None
        
        if len(pdf) ==0 :
            return None
        
        def lambda_ccpl(x):
            code = x[2]
            
            exch_id = self._productData.getExchange(code)
            mo_vm = self._productData.getMultiple(code)
            #presettleprice,settleprice  =  self._baseCtpData.getSettle(code)

            #2019-9-23补丁  by小海     结算价取标的的价格
            under_code = self._productData.getUnderlyingByOptioncode(code)
            settleprice  =  self._snapData.getSettlePrice(under_code)
            #2019-9-23
            
            product = self._productData.getProductByCode(code)
            if product in self._posmap:
                pass
            else:
                self._posmap[product] = { }
            
            if code in self._posmap[product]:
                pass
            else:
                self._posmap[product][code] = [ x[3]-x[5], settleprice, mo_vm, exch_id ]
            
            pass
        
        #上期所cu期权
        if 'cu' in productlist:
            mot = pdf[[bool(re.match(r'^cu\d+[CP]\d+$',i)) for i in pdf[2]]]
            if mot is not None:
                if len(mot) > 0 :        
                    mot.apply( lambda_ccpl, axis = 1)

        #20191121 by  小海  增加上期所ru期权； 
        if 'ru' in productlist:
            mot2 = pdf[[bool(re.match(r'^ru\d+[CP]\d+$',i)) for i in pdf[2]]]
            if mot2 is not None:
                if len(mot2) > 0 :        
                    mot2.apply( lambda_ccpl, axis = 1)

         #20191129 by 小海  增加郑商所CF期权
        if 'CF' in productlist:
            mot3 = pdf[[bool(re.match(r'^CF\d+[CP]\d+$',i)) for i in pdf[2]]]
            if mot3 is not None:
                if len(mot3) > 0 :        
                    mot3.apply( lambda_ccpl, axis = 1)

        #20191212 by 小海   增加大商所i 期权
        if 'i' in productlist:
            mot4 = pdf[[bool(re.match(r'^i\d+-[CP]-\d+$',i)) for i in pdf[2]]]
            if mot4 is not None:
                if len(mot4) > 0 :        
                    mot4.apply( lambda_ccpl, axis = 1)

        return None
    
    def getCodeTotal(self):
        return self._name, self._posmap
        
    def parseJNClearData(self, filepath):
        self.parseJNFile(filepath)
        pass
    
    def parseCtpOptionData(self, ctpfile, productlist):
        self.parseCtpFile_Option(ctpfile, productlist)
        pass

    def parseCtpFutureData(self,  ctpfile):
        self.parseCtpFile_Future(ctpfile)
        pass

#=======================================================================================================================
#======================================================================================================================
def makeHeader(ws):
    titles = [
            ("交易员", 10), 
            ("品种", 10), 
            ("代码", 20), 
            ("持仓数量", 10), 
            ("结算价", 10), 
            ("合约乘数", 10), 
            ("Delta", 10), 
            ("Gamma", 10), 
            ("Vega", 10), 
            ("Theta", 10), 
            ("Rho", 10), 
            ("DeltaTotal", 10), 
            ("GammaTotal", 10), 
            ("VegaTotal", 10), 
            ("ThetaTotal", 10),
            ("RhoTotal", 10),
            ("Imp_v", 10)
               ]
    
    cols_name = [  
            'A', 'B', 'C', 'D', 'E','F','G','H','I','J',
              'K','L','M','N','O','P', 'Q'
              ]
    
    fill_heading = PatternFill('solid', fgColor='C5D9F1')  
    bd = Side(style='thin', color="000000")
    border = Border(left=bd, top=bd, right=bd, bottom=bd)
    ft = Font(name=u'宋体',size=8)
        
    no = 0
    for one in titles:
        # 调整列宽
        ws.column_dimensions[ cols_name[no] ].width = one[1]
            
        cell = ws.cell(row=1, column=no+1)
        cell.value = one[0]
        cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)  # 水平居中，垂直居中
        cell.fill = fill_heading
        cell.border = border
        cell.font = ft
        no += 1

        pass
        
    # 调整行高
    ws.row_dimensions[1].height = 40
    pass

def makeContent(traderlist, ws, dt_today):
    rowno =1
    
    realdt = datetime.datetime.now()
    real_YYYYMMDD = realdt.year*10000 + realdt.month*100 + realdt.day
    want_YYYYMMDD = dt_today.year*10000 + dt_today.month*100 + dt_today.day

    if real_YYYYMMDD == want_YYYYMMDD:
        obj = WindDataHelper.WindGreekData()
    else:
        obj = WindDataHelper.WindGreekDataHistory(dt_today)
        
    obj.start()
    
    for trader in traderlist.values():
        tradername, codemap = trader.getCodeTotal()
        print("$$$$ = ", tradername)
        
        if codemap is None:
            continue
        
        print("$$$$$$ = ", tradername)
        
        lines = len(codemap)
        if lines == 0:
            continue
        
        print("$$$$$$$$ = ", tradername)
        #默认字典，key= code, value =所有同一标的的行数
        option_dt = defaultdict(list)

        ws.cell(rowno+1, 1).value = tradername
        for k, v in codemap.items():
            ws.cell(rowno+1, 2).value = k     #品种
            
            option_dt.clear()

            for key,val in v.items():
                code = key
                ws.cell(rowno+1, 3).value = code        #代码
                ws.cell(rowno+1, 4).value = val[0]      #持仓数量
                ws.cell(rowno+1, 5).value = val[1]      #结算价
                ws.cell(rowno+1, 6).value = val[2]      #合约乘数

                exch_id = val[3]
            
                if len(code) >8:
                    #期权
                    #TODO
                    data = obj.getGreekData(code, exch_id)
                    if data.ErrorCode != 0:
                        print("GetWindData Error ===========")
                    else:
                        print(data)
                        ws.cell(rowno+1, 7).value = data.Data[1][0]     # delta
                        ws.cell(rowno+1, 8).value = data.Data[2][0]     # gamma
                        ws.cell(rowno+1, 9).value = data.Data[3][0]      # vega
                        ws.cell(rowno+1, 10).value = data.Data[4][0]     # theta
                        ws.cell(rowno+1, 11).value = data.Data[5][0]       # rho
                    
                        ws.cell( rowno +1, 12).value = "=D{0}*E{0}*F{0}*G{0}".format( rowno + 1)
                        ws.cell( rowno +1, 13).value = "=D{0}*E{0}*E{0}*F{0}*H{0}/100".format( rowno + 1)
                        ws.cell( rowno +1, 14).value = "=D{0}*F{0}*I{0}".format( rowno + 1)
                        ws.cell( rowno +1, 15).value = "=D{0}*F{0}*J{0}".format( rowno + 1)
                        ws.cell( rowno +1, 16).value = "=D{0}*F{0}*K{0}".format( rowno + 1)
                        ws.cell( rowno +1, 17).value = data.Data[0][0]   # Imp_vol

                        option_dt[ code[:6] ].append(  rowno+1 )
                    
                    pass
                else:
                    #期货
                    ws.cell( rowno +1, 7).value = 1
                    ws.cell( rowno +1, 12).value = "=D{0}*E{0}*F{0}*G{0}".format( rowno + 1)
                    
                    #补丁
                    global g_total_data
                    if g_total_data:
                        g_total_data.addFuture_Info(tradername, code, rowno+1)
                    #end
                    
                    pass
                
                rowno += 1
            pass

            #20190909 如果有场内期权部分
            if len(option_dt) >0:
                for code, v in option_dt.items():
                    ws.cell(rowno+1, 3).value = code        #代码

                    ws.cell( rowno +1, 12).value = "= " + "+".join( ["L{0}".format(i) for i in v ] )
                    ws.cell( rowno +1, 13).value = "= " + "+".join( ["M{0}".format(i) for i in v ] )
                    ws.cell( rowno +1, 14).value = "= " + "+".join( ["N{0}".format(i) for i in v ] )
                    ws.cell( rowno +1, 15).value = "= " + "+".join( ["O{0}".format(i) for i in v ] )
                    ws.cell( rowno +1, 16).value = "= " + "+".join( ["P{0}".format(i) for i in v ] )

                    #补丁
                    if g_total_data:
                        g_total_data.addOption_Info(tradername, code, rowno+1)
                    #end

                    rowno += 1
                    pass


        pass
    pass

def make_EveryTrader(traderlist,  workbook,  worksheet, dt_today):
    
    makeHeader( worksheet)
    
    makeContent(traderlist, worksheet, dt_today)
    pass



def makeReport(rootdir, traderlist, dt_today):
    reportdir = os.path.join( rootdir, "report")
    
    filename = "{0}-{1}-{2}风险管理部门Greeks报表.xlsm".format( dt_today.year,  dt_today.month, dt_today.day)
    filepath = os.path.join(reportdir, filename)
    
    #TODO
    datadir = os.path.join( rootdir, "dataotc")
    srcpath = os.path.join(  datadir, "Blank模板勿删(Greek).xlsm")
    if os.path.exists(filepath):
        pass
    else:
        shutil.copyfile(srcpath,   filepath)
    #TODO
    
    workbook = openpyxl.load_workbook(filepath, keep_vba = True)
    #按序号获取sheet
    worksheet = workbook.worksheets[4]
    
    #填写按交易员按品种汇总
    make_EveryTrader(traderlist, workbook, worksheet, dt_today)
    
    workbook.save(filepath)
    workbook.close()
    pass

#功能: 扫描结算数据目录，寻找某个账号在dt_today的文件
def scan_find(rootdir, dt_today, account):
    curdir = os.path.join( rootdir, "datactp_jn")
    if not os.path.exists(curdir):
        return None

    date_str1 = "%04d-%02d-%02d" % ( dt_today.year,  dt_today.month, dt_today.day )
    date_str2 = str(  dt_today.year*10000 + dt_today.month*100 +dt_today.day ) 

    oblist = os.listdir(curdir)
    for one in oblist:
        opath = os.path.join(curdir, one)
        
        if os.path.isfile(opath):
            if os.path.splitext(one)[1] == '.txt':
                if one.find(date_str1) >= 0 or one.find(date_str2) >= 0:
                    if one.startswith( account ):
                        return opath
    
    return None

#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
def main(rootdir, dt_today):
    tmap = {    
                "林秉玮":('0009', 'jn'), 
                "谢晨星":('0019', 'jn'), 
                "何剑桥":('0029', 'jn'),  
                "刘剑溥":('0039', 'jn'),
                "888888":('8001888888', 'ctp1'),   
                "911005":('9110000005', 'ctp2'),
                "911002":('9110000002', 'ctp2')
            }

    #[1]基础数据
    oproduct = BD.CProductData()
    baseobj =  BD.CSnapData(dt_today)
    
    #[2]
    #每个结算单，有交易员名字和交易日期，按交易员分析
    traderlist = {}
    for  k, v in tmap.items():
        filepath = scan_find(rootdir, dt_today, v[0] )
        if filepath is None:
            continue
        
        if k == '888888':
            if "谢晨星" in traderlist:
                xie_product_list=['cu', 'ru']
                traderlist["谢晨星"].parseCtpOptionData(filepath, xie_product_list)
            if "刘剑溥" in traderlist:
                liu_product_list=['CF', 'i']
                traderlist["刘剑溥"].parseCtpOptionData(filepath, liu_product_list)
        else:
            trader = Trader(k)
            trader.setBaseData(baseobj, oproduct)
            if v[1] == 'ctp2':
                trader.parseCtpFutureData(filepath)
            else:
                trader.parseJNClearData(filepath)

            traderlist[k] = trader


    #[4]汇总并输出报表
    makeReport(rootdir, traderlist, dt_today)
    
    pass



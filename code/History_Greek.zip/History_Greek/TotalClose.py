# -*- coding: utf-8 -*-
"""
Created on Thu Aug 29 15:15:37 2019

@author: pengdk
"""

import os
import openpyxl    #读写xlsx 
import datetime
from openpyxl.styles import Color,Font,Alignment,PatternFill,Border,Side,Protection
import shutil
import pymysql



#收盘价汇总
class TotalCloseData(object):
    def __init__(self):
        self._tradermap = { }   # trader ===> map(code, [   ]) 
        pass
    
    #添加场外的汇总结果
    def addOTC_Info(self, trader, code, rowno):
        if trader in self._tradermap:
            if code in self._tradermap[trader]:
                self._tradermap[trader][code][0] = rowno
            else:
                self._tradermap[trader][code] = [ rowno, 0, 0 ]
            pass
        else:
            self._tradermap[trader] = {}
            self._tradermap[trader][code] = [ rowno, 0, 0 ]
            pass
        pass
    
    #添加场内期货的汇总结果
    def addFuture_Info(self, trader, code, rowno):
        if trader in self._tradermap:
            if code in self._tradermap[trader]:
                self._tradermap[trader][code][1] = rowno
            else:
                self._tradermap[trader][code] = [ 0, rowno, 0 ]
            pass
        else:
            self._tradermap[trader] = {}
            self._tradermap[trader][code] = [ 0, rowno, 0 ]
            pass
        pass

    #添加场内期权的汇总结果
    def addOption_Info(self, trader, code, rowno):
        if trader in self._tradermap:
            if code in self._tradermap[trader]:
                self._tradermap[trader][code][2] = rowno
            else:
                self._tradermap[trader][code] = [ 0, 0 ,rowno]
            pass
        else:
            self._tradermap[trader] = {}
            self._tradermap[trader][code] = [ 0, 0, rowno ]
            pass
        pass
    
    def get2ndMap(self):
        return self._tradermap


class TotalCloseMain(object):
    def __init__(self):
        pass
    
    def setData(self, bdata):
        self._data = bdata
        pass
    
    
    def writeSubHeader(self, ws, rowno):
        fill_01 = PatternFill('solid', fgColor='F4B084')  
        fill_02 = PatternFill('solid', fgColor='C5D9F1') 
        fill_03 = PatternFill('solid', fgColor='FF0000') 
        
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        
        ft = Font(name=u'宋体',size=8, color = 'C65911', bold = True)
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        titles = ["交易员", "代码", "总计Delta", "Gamma", "Vega", "Theta", "Rho", "iv", 
                  "Delta", "Gamma", "Vega", "Theta", "Rho", "风控标准", "是否符合标准"]
        
        cols_name = ['A', 'B', 'C', 'D', 'E','F','G','H','I','J',
              'K','L','M','N','O','P','Q','R','S','T',
              'U','V','W','X','Y','Z'
              ]
        
        no = 0
        for one in titles:
            # 调整列宽
            ws.column_dimensions[ cols_name[no] ].width = 14
           
            cell = ws.cell(row=rowno, column=no+1)
            cell.value = one
            cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)  # 水平居中，垂直居中
            cell.border = border
            
            if no == 0:
                cell.fill = fill_01
                cell.font = normalft
                pass
            elif no < 8:
                cell.font = ft
            elif no <13:
                cell.font = normalft
                cell.fill = fill_02
            elif no == 13:
                cell.font = normalft
                cell.fill = fill_03
            else:
                cell.font = ft
            
            no += 1

            pass
        
        # 调整行高
        ws.row_dimensions[rowno].height = 15  
        
        pass
    
    def writeSubContent(self, ws, beginrow):
        
        self._remap = { }
        
        kmap = self._data.get2ndMap()
        
        print("------------------------------")
        print(kmap)
        print("------------------------------")
        
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        rowno = beginrow
        for trader, vmap in kmap.items():
            cell = ws.cell(rowno, 1)
            cell.value = trader
            cell.font = normalft
            
            self._remap[trader] = [ ]
            
            for k, v in vmap.items():
                code = k
                
                cell = ws.cell(rowno, 2)
                cell.value = code
                cell.font = normalft
                
                if v[0] >0:
                    ws.cell(rowno, 3).value = "=场外期权Greek收盘价!C{0}".format( v[0])    #Delta
                    ws.cell(rowno, 4).value = "=场外期权Greek收盘价!D{0}".format( v[0])    #Gamma
                    ws.cell(rowno, 5).value = "=场外期权Greek收盘价!E{0}".format( v[0])    #Vega
                    ws.cell(rowno, 6).value = "=场外期权Greek收盘价!F{0}".format( v[0])    #Theta
                    ws.cell(rowno, 7).value = "=场外期权Greek收盘价!G{0}".format( v[0])    #Rho
                    ws.cell(rowno, 8).value = "=场外期权Greek收盘价!H{0}*100".format( v[0])    #iv
                    
                    ws.cell(rowno, 3).font = normalft
                    ws.cell(rowno, 4).font = normalft
                    ws.cell(rowno, 5).font = normalft
                    ws.cell(rowno, 6).font = normalft
                    ws.cell(rowno, 7).font = normalft
                    ws.cell(rowno, 8).font = normalft
                
                if v[1] >0 and v[2] >0:
                    ws.cell(rowno, 9 ).value = "=场内Greek收盘价!L{0}+场内Greek收盘价!L{1}".format( v[1], v[2])         #Delta
                    ws.cell(rowno, 10).value = "=场内Greek收盘价!M{0}+场内Greek收盘价!M{1}".format( v[1], v[2])         #Gamma
                    ws.cell(rowno, 11).value = "=场内Greek收盘价!N{0}+场内Greek收盘价!N{1}".format( v[1], v[2])         #Vega
                    ws.cell(rowno, 12).value = "=场内Greek收盘价!O{0}+场内Greek收盘价!O{1}".format( v[1], v[2])         #Theta
                    ws.cell(rowno, 13).value = "=场内Greek收盘价!P{0}+场内Greek收盘价!P{1}".format( v[1], v[2])  
                else:
                    val =0
                    if v[1] >0:
                        val = v[1]
                    if v[2] >0:
                        val = v[2]
                        
                    if val >0:
                        ws.cell(rowno, 9 ).value = "=场内Greek收盘价!L{0}".format( val)         #Delta
                        ws.cell(rowno, 10).value = "=场内Greek收盘价!M{0}".format( val)         #Gamma
                        ws.cell(rowno, 11).value = "=场内Greek收盘价!N{0}".format( val)         #Vega
                        ws.cell(rowno, 12).value = "=场内Greek收盘价!O{0}".format( val)         #Theta
                        ws.cell(rowno, 13).value = "=场内Greek收盘价!P{0}".format( val)         #Rho
                    
                ws.cell(rowno, 9).font = normalft
                ws.cell(rowno, 10).font = normalft
                ws.cell(rowno, 11).font = normalft
                ws.cell(rowno, 12).font = normalft
                ws.cell(rowno, 13).font = normalft
                pass
                
                #写入风控标准
                ws.cell(rowno, 14).font = normalft
                ws.cell(rowno, 14).value = "=MAX(1000000, ABS(0.5*D{0}*2 * H{0}/SQRT(245)))".format( rowno)
                ws.cell(rowno, 15).font = normalft
                ws.cell(rowno, 15).value = '=IF(ABS(C{0}+I{0})<ABS(N{0}),"是","否")'.format(rowno)
                
                self._remap[trader].append(rowno )
                
                #
                rowno += 1
                pass
        pass
    
    def writeSubData(self, wb):
        ws = wb.worksheets[0]
        
        beginrow = 20
        
        self.writeSubHeader(ws, beginrow)               #写入Header
        self.writeSubContent(ws, beginrow +1 )          #写入内容
        
        pass

    def writeMainHeader(self, ws, beginrow):
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        
        ft = Font(name=u'宋体',size=8, color = 'C65911', bold = True)
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        rowno = beginrow
        
        colno = 1
        #[1]写Header
        titles = ['总delta', 'Delta', 'Gamma', 'Vega', 'Theta', 'Rho', '单交易员风控标准', '是否符合标准']
        for title in titles:
            cell = ws.cell(rowno, colno)
            cell.value = title
            cell.border = border
            cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)  # 水平居中，垂直居中
            cell.font = ft if colno > 6 else normalft
            colno += 1
        
        #[2]留出交易员 和 "保险+期货" 的空格
        rowno += 5
        
        #[3]写入部门风控标准 #[4]写入是否符合风控
        rowno += 1
        li_01 = [ ['部门风控标准', '=SUM(G4:G8)', '2000000', '1000000'],
                  ['是否符合风控标准', '=IF(ABS(B11)<ABS(B9),"是","否")', '=IF(ABS(D11)<ABS(D9),"是","否")', '=IF(ABS(E11)<ABS(E9),"是","否")']
                   ]
        pos_01 = [ 1, 2, 4, 5]
        
        for i in range(2):
            
            j =0
            for colno in pos_01:
                cell = ws.cell(rowno, colno)
                cell.value = li_01[i][j]
                
                if j == 0:
                    cell.border = border
                    cell.font = ft
                else:
                    cell.font = normalft
                    
                j += 1
                pass
           
            rowno += 1
            
        
        #[5]写入合计
        li_02 = ['合计', '=SUM(B4:B8)', '=SUM(C4:C8)', '=SUM(D4:D8)', '=SUM(E4:E8)', '=SUM(F4:F8)']
        colno = 1
        for one in li_02:
            cell = ws.cell( rowno, colno)
            cell.value = one
            cell.font = normalft
            
            if colno == 0:
                cell.border = border
            
            colno += 1
            pass
        
        pass
    
    def writeMainContent(self, ws, beginrow):
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        rowno = beginrow
        for trader, li in self._remap.items():
            cell = ws.cell(rowno, 1)
            cell.value = trader
            cell.border = border
            cell.font = normalft
            
            begin = li[0]
            end = li[-1]
            
            for i in range(7):
                cell = ws.cell( rowno, 2+ i)
                cell.font = normalft
                
                if i ==0:
                    cell.value = '=SUM(C{0}:C{1})+SUM(I{0}:I{1})'.format( begin, end )
                elif i == 1:
                    cell.value = '=SUM(D{0}:D{1})+SUM(J{0}:J{1})'.format( begin, end )
                elif i == 2:
                    cell.value = '=SUM(E{0}:E{1})+SUM(K{0}:K{1})'.format( begin, end )
                elif i == 3:
                    cell.value = '=SUM(F{0}:F{1})+SUM(L{0}:L{1})'.format( begin, end )
                elif i == 4:
                    cell.value = '=SUM(G{0}:G{1})+SUM(M{0}:M{1})'.format( begin, end )
                elif i == 5:
                    cell.value = '=SUM(N{0}:N{1})'.format( begin, end )
                elif i == 6:
                    cell.value = '=IF(ABS(B{0})<ABS(G{0}),"是","否")'.format( rowno )
                
                pass
            
            
            rowno += 1
            pass
        
        pass
    
    def writeMainData(self, wb):
        ws = wb.worksheets[0]
        beginrow = 3
        
        self.writeMainHeader(ws, beginrow)
        
        self.writeMainContent(ws, beginrow+1)
        
        pass


    def writeTotal(self, filepath):
        wb = openpyxl.load_workbook(filepath, keep_vba = True)
    
        #填写 每个交易员分项 的数据
        self.writeSubData(wb)
        
        #填写 汇总的数据
        self.writeMainData(wb)
            
        # Save the file
        wb.save(filepath)
        
        return None


#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
def main(rootdir, _totaldata , dt_today):
    reportdir = os.path.join(rootdir, "report")
    
    filename = "{0}-{1}-{2}风险管理部门Greeks报表.xlsm".format( dt_today.year,  dt_today.month, dt_today.day)
    filepath = os.path.join(reportdir, filename)
    
    datadir = os.path.join(rootdir, "dataotc")
    srcpath = os.path.join(  datadir, "Blank模板勿删(Greek).xlsm")
    if os.path.exists(filepath):
        pass
    else:
        shutil.copyfile(srcpath,   filepath)
  
    
    obj = TotalCloseMain()
    obj.setData( _totaldata )
    
    obj.writeTotal(filepath )
    
    pass










































# -*- coding: utf-8 -*-
"""
Created on Wed Aug 21 14:46:20 2019

@author: pengdk
"""

import os
import openpyxl    #读写xlsx 
import datetime
from openpyxl.styles import Color,Font,Alignment,PatternFill,Border,Side,Protection
import shutil
import pymysql

import BaseData as BD
#模块级别的变量

#用来记录 交易员+品种+行号 ; 类型为TotalCloseData
g_total_data = None

#======================================================================================================================
class Trader(object):
    def __init__(self, name):
        self._name = name
        self._codemap = {}    # key = code  value = []    #某个代码，分布的行号
        pass
    
    def addCodeLine(self, code, rowno):
        if code in self._codemap:
            self._codemap[code].append( rowno )
            pass
        else:
            self._codemap[code] = [ rowno ]
        pass
    
    def getName(self):
        return self._name
    
    def getCodemapLines(self):
        return self._codemap
    
    
#=======================================================================================================================
class historyAccount(object):
    def __init__(self):
        self._tradermap = {}    #key=交易员  value=trader
        
        self._midmap = {}     # key = code  value = （mid波动率， 成交波动率）   #某个代码的mid波动率，后面覆盖前面
        pass
    
    def setData(self, holiday_obj, snapdata_obj):
        self._oholiday = holiday_obj
        self._osnapdata = snapdata_obj
        pass

    #计算剩余天数(从今日开始，计算到enddate中间的工作日，算尾不算头)
    def calcLeftDays(self, enddate, dt_today):
        return self._oholiday.calcLeftDays(enddate, dt_today)
    
    def calcPreWorkdate(self, dt_today):
        return self._oholiday.preWorkDay( dt_today)
    
    def helperdate(self, dt):
        d = dt.date()
        return d.year*10000 +  d.month*100 + d.day

    def readAccount(self, curdir, dt_today):
        filepath = os.path.join(curdir, "场外台账.xlsx")
        
        self._dt_today = dt_today
        today = dt_today.year*10000 + dt_today.month*100 + dt_today.day
        
        wb = openpyxl.load_workbook( filepath)
        ws = wb.active
        
        rows = []
        #按行循环
        idx = 0
        for row in ws.iter_rows():
            idx += 1
            if idx == 1:        #第一行是标题
                continue
            
            trader = row[0].value   #交易员
            if trader is None:      #没有交易员的行，是无效的
                continue
                
            if len(trader) ==0:
                continue
                
            enddate = self.helperdate( row[6].value )#最后到期日
            if enddate < today:
                continue
            
            later = row[19].value   #平仓日期
            if later is not None:
                el_date = self.helperdate( later )
                if el_date < today:
                    continue
                
            pcdate = row[22].value   #结算日期
            if pcdate is not None:
                #print("====$$=====", pcdate)
                el_date = self.helperdate( pcdate )
                if el_date < today:
                    continue
                
            #TODO
            ##因为是历史版本，台账中有未来数据,所以，任何开始日期大于today的，也要过滤    
            begindate = self.helperdate( row[5].value )   
            if begindate > today:
                continue
            #TODO    
                
            #补丁 2019-8-29
            trader.strip()
            if trader in self._tradermap:
                pass
            else:
                self._tradermap[trader] = Trader(trader)
            #end
            
            rows.append(  row )

            idx += 1
            
        print( len(rows))  
        return self.filterRead(rows)


    def filterRead(self, rows):
        t = self._dt_today
        today = t.year*10000 + t.month*100 + t.day
        
        today_rows = []
        later_rows = []
        
        '''
        当日存续的产品中，再次区分；"非当日了结" 和 "当日了结"
        当日了结:
            1. 最后日期为今日
            2. 平仓日期有值，并且等于今日
            3. 行权日期有值，并且等于今日
        '''
        
        for  row  in rows:
            enddate = self.helperdate( row[6].value )#最后到期日
            if enddate == today:
                today_rows.append(row)
                continue
            
            later = row[19].value   #平仓日期
            if later is not None:
                el_date = self.helperdate( later )
                if el_date == today:
                    today_rows.append(row)
                    continue
            
            pcdate = row[22].value   #结算日期
            if pcdate is not None:
                el_date = self.helperdate( pcdate )
                if el_date == today:
                    today_rows.append(row)
                    continue
                
            later_rows.append(  row )    
            pass
        
        return today_rows, later_rows

    def reArrangeGreek(self, ws, rows, begin_rowno):
        fill_yellow = PatternFill('solid', fgColor='FFFF00')  
        #fill_pink = PatternFill('solid', fgColor='FCD5B4')
        
        '''
        有3类特殊的，要标识黄色:
            1, 标的是价差
            2, 类型是奇异的,或者亚欧
            3, 单位权利金为0， 表示远期的
        '''
        
        rowno = begin_rowno
        for row in rows:
            bret = False
            
            code = row[7].value
            
            #补丁2019-8-29
            #midiv = row[29].value   #mid波动率
            self._midmap[code] = (row[29].value, row[28].value)
            #end
            
            cptype = row[9].value       #类型
            remark = row[30].value
            if len(code) >8:
                bret = True
            
            if cptype and len(cptype) != 4:
                bret = True
            
            if remark:
                if remark.find('互换') >=0:
                    bret = True
                if remark.find('远期') >=0:
                    bret = True
                if remark.find('保险') >=0:
                    bret = True
                if remark.find('Collar') >=0:
                    bret = True
                if remark.find('Delta') >=0:
                    bret = True
            
            if bret:
                for i in range(33):
                    cell = ws.cell(rowno + 1, i+1)
                    cell.fill = fill_yellow
                    #if i == 27 or i==28:    
                    #    cell.value = ''
                    pass
              
            rowno += 1    
            pass
    
        pass
    
    
    def writeGreekHeader(self, ws):
        titles = [
        ("交易员" , 10),
        ("客户名称", 30),
        ("标的	", 10),
        ("客户交易方向	", 10),
        ("类型	", 10),
        
        ("数量(吨）", 10),
        ("行权价", 10),
        ("入场价", 10),	
        ("类型", 10),        
        ("交易方向(我方)", 10),
        
        ("进场波动度", 10),
        ("天数	", 10),
        ("期权计算日	", 20),
        ("Risk-free rate ( r )	", 10),
        ("Cost of carry ( b )	", 10),
        
        ("今日收盘价格	", 10),
        ("Delta",  10),
        ("Gamma",  10),
        ("Vega",  10),
        ("Theta Q",  10),
        
        ("Rho r",  10),
        ("Delta Total",  10),
        ("Gamma Total",  10),
        ("Vega Total",  10),
        ("Theta Total",  10),
        
        ("Rho Total",  10),
        ("昨日计算日", 10),
        ("昨日收盘价格 ", 10),
        ("Delta(T-1)", 10),
        ("Gamma(T-1)", 10),
        
        ("Vega(T-1)", 10),
        ("Theta(T-1)", 10),
        ("Rho(T-1)", 10)
        ]
        
        cols_name = ['A', 'B', 'C', 'D', 'E','F','G','H','I','J',
              'K','L','M','N','O','P','Q','R','S','T',
              'U','V','W','X','Y','Z','AA','AB','AC','AD',
              'AE','AF','AG'
              ]
        
        fill_heading = PatternFill('solid', fgColor='C5D9F1')  
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        ft = Font(name=u'宋体',size=8)
        fill_pink = PatternFill('solid', fgColor='FCD5B4')
        
        for no, one in enumerate(titles):
            # 调整列宽
            ws.column_dimensions[ cols_name[no] ].width = one[1]
            
            cell = ws.cell(row=1, column=no+1)
            cell.value = one[0]
            cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)  # 水平居中，垂直居中
            
            cell.border = border
            cell.font = ft
            cell.fill = fill_heading
            if no > 25:
                cell.fill = fill_pink

            pass
        # 调整行高
        ws.row_dimensions[1].height = 40
        pass
    
    def writeGreekContent(self, ws, rows,  begin_rowno):
        #cols = 15
        
        fill_content = PatternFill('solid', fgColor='D9D9D9')  # 灰色
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        ft = Font(name=u'宋体',size=8)
        fill_xie = PatternFill('solid', fgColor='F79646') 
        fill_liu = PatternFill('solid', fgColor='DA9694') 
        fill_he = PatternFill('solid', fgColor='B8CCE4') 
        fill_lin = PatternFill('solid', fgColor='B1A0C7') 
        #fill_blue = PatternFill('solid', fgColor='2FA4E7')
        
        rowno = begin_rowno
        
        for row in rows:
            cur_code = row[7].value
            _precloseprice =0
            _closeprice =0
            try:
                _precloseprice, _closeprice = self._osnapdata.getClosePrice(cur_code)
            except:
                pass

            for i in range(33):
                cell = ws.cell(rowno + 1, i+1)
                cell.alignment = Alignment(horizontal='center', vertical='center')  # 水平居中，垂直居中
                cell.border = border
                cell.font = ft
                cell.fill = fill_content
                
                if i == 0:  #交易员A
                    cell.value= row[0].value
                elif i ==1:  #客户名称B
                    cell.value = row[3].value
                    
                    trader = row[0].value
                    if trader == '谢晨星':
                        cell.fill = fill_xie
                    elif trader == '刘剑溥':
                        cell.fill = fill_liu
                    elif trader == '何剑桥':
                        cell.fill = fill_he
                    elif trader == '林秉玮':
                        cell.fill = fill_lin
                        
                elif i == 2:  #标的 C
                    code = row[7].value
                    cell.value = code
                    trader = row[0].value
                    trader.strip()
                    self._tradermap[trader].addCodeLine(code, rowno + 1)
                    
                elif i ==3:  #客户交易方向D
                    cell.value = row[8].value
                elif i == 4:    #"类型	"E
                    cell.value = row[9].value
                elif i == 5:#"数量(吨）F
                    cell.value = row[10].value
                elif i == 6:#"行权价"G
                    cell.value = row[11].value
                elif i == 7:#"入场价"H
                    cell.value = row[12].value
                elif i ==8: #BS类型  I
                    cell.value = 'C' if row[9].value and len(row[9].value) >2 and (row[9].value)[-2:] == '看涨' else 'P'
                elif i == 9: #交易方向(我方) J
                    cell.value =  -1.0 if row[8].value == "买入" else 1.0
                    cell.number_format = '0.00'
                elif i == 10: #进场波动度 K
                    cell.value = row[28].value
                    cell.number_format = '0.00%'
                elif i == 11: #天数 L
                    cell.value = self.calcLeftDays( row[6].value , self._dt_today)
                elif i == 12: #期权计算日 M
                    cell.value = self._dt_today.strftime("%Y-%m-%d ") + "15:00:01"
                elif i == 13: #Risk-free rate ( r ) N
                    cell.value = 0.045
                    cell.number_format = '0.00%'  
                elif i == 14:  #Cost of carry ( b ) O
                    cell.value = 0
                elif i == 15:  #今日收盘价格 P
                    cell.value = _closeprice
                    #cell.value = r"='C:\Wind\Wind.NET.Client\WindNET\DataBrowse\XLA\WindFunc.xla'!S_DQ_Close(C{0},M{0})".format(rowno+1)
                elif i == 16: #Delta    Q
                    cell.value = "=GDelta(I{0},P{0},G{0},L{0}/245,N{0},O{0},K{0})*J{0} ".format(rowno+1)
                elif i == 17: #Gamma    R
                    cell.value = "=GGamma(P{0},G{0},L{0}/245,N{0},O{0},K{0})*J{0} ".format(rowno+1)
                elif i == 18: #Vega     S
                    cell.value = "=GVega(P{0},G{0},L{0}/245,N{0},O{0},K{0})/100*J{0} ".format(rowno+1)
                elif i == 19: #Theta    T
                    cell.value = "=GTheta(I{0},P{0},G{0},L{0}/245,N{0},O{0},K{0})/245*J{0} ".format(rowno+1)    
                elif i == 20: #Rho      U
                    cell.value = "=GRho(I{0},P{0},G{0},L{0}/245,N{0},O{0},K{0})/100 ".format(rowno+1)    
                elif i== 21:  #Delta Total  V
                    cell.value = "= Q{0} * F{0} * P{0}".format(rowno+1)  
                elif i == 22: #Gamma Total  W
                    cell.value = "= R{0} * F{0} * P{0} * P{0}/100".format(rowno+1)  
                elif i == 23: #Vega Total   X
                    cell.value = "= S{0} * F{0} ".format(rowno+1)  
                elif i == 24: #Theta Total    Y
                    cell.value = "= T{0} * F{0} ".format(rowno+1) 
                elif i == 25: #Rho Total    Z
                    cell.value = "= U{0} * F{0} ".format(rowno+1)
                
                elif i == 26: #昨日计算日    AA
                    pre_dt = self.calcPreWorkdate(self._dt_today)
                    cell.value = pre_dt.strftime("%Y-%m-%d ") + "15:00:01"
                elif i == 27:#昨日收盘价格  AB
                    cell.value = _precloseprice
                    #cell.value = r"='C:\Wind\Wind.NET.Client\WindNET\DataBrowse\XLA\WindFunc.xla'!S_DQ_Close(C{0}, AA{0})".format(rowno+1)
                elif i == 28: #Delta(T-1)   AC
                    cell.value = "=GDelta(I{0},AB{0},G{0},(L{0}+1)/245,N{0},O{0},K{0})*J{0} ".format(rowno+1)
                elif i == 29: #Gamma(T-1)    AD
                    cell.value = "=GGamma(AB{0},G{0},(L{0}+1)/245,N{0},O{0},K{0})*J{0} ".format(rowno+1)
                elif i == 30: #Vega(T-1)     AE
                    cell.value = "=GVega(AB{0},G{0},(L{0}+1)/245,N{0},O{0},K{0})/100*J{0} ".format(rowno+1)
                elif i == 31: #Theta(T-1)    AF
                    cell.value = "=GTheta(I{0},AB{0},G{0},(L{0}+1)/245,N{0},O{0},K{0})/245*J{0} ".format(rowno+1)    
                elif i == 32: #Rho(T-1)      AG
                    cell.value = "=GRho(I{0},AB{0},G{0},(L{0}+1)/245,N{0},O{0},K{0})/100 ".format(rowno+1) 
                else:
                    cell.value = ""
                pass
            rowno += 1
            ws.row_dimensions[rowno].height = 20
        
        pass
    
    def writeGreek(self, wb, later_rows, today_rows):
        #按序号获取sheet
        ws = wb.worksheets[1]
        
        #[1]写入标题
        self.writeGreekHeader(ws)
        
        #[2]写入 非当日了结 内容，并check
        begin_rowno = 1
        self.writeGreekContent(ws, later_rows, begin_rowno)
        self.reArrangeGreek(ws, later_rows,  begin_rowno)
        
        return 5 + len(later_rows)
    
    
    def writeTraderHeader(self, ws, rowno):
        fill_heading = PatternFill('solid', fgColor='F4B084')  
        bd = Side(style='thin', color="000000")
        border = Border(left=bd, top=bd, right=bd, bottom=bd)
        ft = Font(name=u'宋体',size=8, color = 'C65911', bold = True)
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        titles = ["交易员", "代码", "总计Delta", "Gamma", "Vega", "Theta", "Rho", "iv"]
        no = 0
        for one in titles:
           
            cell = ws.cell(row=rowno, column=no+1)
            cell.value = one
            cell.alignment = Alignment(horizontal='center', vertical='center', wrapText=True)  # 水平居中，垂直居中
            cell.border = border
            
            if no == 0:
                cell.fill = fill_heading
                cell.font = normalft
                pass
            else:
                cell.font = ft
            
            no += 1

            pass
        
        # 调整行高
        ws.row_dimensions[rowno].height = 30    
        pass
    
    def writeTrader( self, wb, lastrow):
        ws = wb.worksheets[1]
        
        begin_row = lastrow
        self.writeTraderHeader(ws, begin_row)
        
        normalft = Font(name=u'宋体',size=8, color = '000000')
        
        rowno = begin_row+1
        for trader,obj in self._tradermap.items():
            cell = ws.cell(rowno, 1)
            cell.value = obj.getName()
            cell.font = normalft
            
            codemap = obj.getCodemapLines()
            for k, v in codemap.items():
                code  = k
                ws.cell(rowno, 2).value = code
                ws.cell(rowno, 3).value = "= " + "+".join( ["V{0}".format(i) for i in v ] )
                ws.cell(rowno, 4).value = "= " + "+".join( ["W{0}".format(i) for i in v ] )
                ws.cell(rowno, 5).value = "= " + "+".join( ["X{0}".format(i) for i in v ] )
                ws.cell(rowno, 6).value = "= " + "+".join( ["Y{0}".format(i) for i in v ] )
                ws.cell(rowno, 7).value = "= " + "+".join( ["Z{0}".format(i) for i in v ] )
                
                if code in self._midmap:
                    mid,trade = self._midmap[code]
                    if mid:
                        ws.cell(rowno, 8).value = mid
                    else:
                        ws.cell(rowno, 8).value = trade
                
                #补丁
                global g_total_data
                if g_total_data:
                    g_total_data.addOTC_Info(trader, code, rowno)
                #end
                
                rowno += 1
            pass
    
        pass
    
    def writeTemplate(self, filepath, later_rows, today_rows):
        
        wb = openpyxl.load_workbook(filepath, keep_vba = True)
    
        #写入希腊字母
        lastrow = self.writeGreek( wb, later_rows, today_rows)
        
        #写入按交易员的统计
        self.writeTrader( wb, lastrow)
            
        # Save the file
        wb.save(filepath)
        
        return None



#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
#=======================================================================================================================
def main( rootdir, dt_today):
    reportdir = os.path.join( rootdir, "report")
    
    filename = "{0}-{1}-{2}风险管理部门Greeks报表.xlsm".format( dt_today.year,  dt_today.month, dt_today.day)
    filepath = os.path.join(reportdir, filename)
    
    datadir = os.path.join( rootdir, "dataotc")
    srcpath = os.path.join(  datadir, "Blank模板勿删(Greek).xlsm")
    if os.path.exists(filepath):
        pass
    else:
        shutil.copyfile(srcpath,   filepath)
  
    #[1]
    oholiday = BD.CHolidayData()
    pre_workday = oholiday.preWorkDay(dt_today)

    baseobj = BD.CSnapData4(dt_today,  pre_workday)
    baseobj.start()

    #[2]
    obj = historyAccount()
    obj.setData(oholiday, baseobj)
    today_rows, later_rows = obj.readAccount(datadir,  dt_today)
    obj.writeTemplate(filepath, later_rows, today_rows)
    
    pass


